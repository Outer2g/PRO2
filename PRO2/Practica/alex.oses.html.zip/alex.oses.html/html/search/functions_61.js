var searchData=
[
  ['actualizar',['actualizar',['../class_ranking.html#acf63187d3222d4f23c0828a4fb9f7c7b',1,'Ranking']]]
];
