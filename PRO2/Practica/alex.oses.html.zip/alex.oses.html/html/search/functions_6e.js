var searchData=
[
  ['nuevo_5fhijo',['nuevo_hijo',['../class_ranking.html#a7265b27c9413acc7db65b9e815f3be64',1,'Ranking']]],
  ['nuevo_5forganismo',['nuevo_organismo',['../class_ranking.html#afa2e8a90b29c55dafbbede7db8ac4ad8',1,'Ranking']]]
];
