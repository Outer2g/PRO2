var searchData=
[
  ['ranking',['Ranking',['../class_ranking.html',1,'Ranking'],['../class_ranking.html#af700e3f1e24eb35173adff4fbcac7c68',1,'Ranking::Ranking()']]],
  ['ranking_2ehpp',['Ranking.hpp',['../_ranking_8hpp.html',1,'']]],
  ['recorte',['recorte',['../class_organisme.html#a1f97e234776174573cfb761e7697dc37',1,'Organisme']]],
  ['recorte_5fid',['recorte_id',['../class_cjt__organismes.html#a33b52c7d797c0ee244e3c77cb4d2b86e',1,'Cjt_organismes']]],
  ['reproduccion_5forg',['reproduccion_org',['../class_organisme.html#a589195c1a83c096fcd7487a8b9a8a0a7',1,'Organisme']]],
  ['ronda',['ronda',['../class_cjt__organismes.html#ab6061ae3fc10ae709a2584335e687271',1,'Cjt_organismes']]]
];
