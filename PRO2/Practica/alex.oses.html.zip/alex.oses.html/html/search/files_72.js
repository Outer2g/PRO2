var searchData=
[
  ['ranking_2ehpp',['Ranking.hpp',['../_ranking_8hpp.html',1,'']]]
];
