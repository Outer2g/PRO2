var searchData=
[
  ['main',['main',['../_programa_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'Programa.cpp']]],
  ['muerto',['muerto',['../class_organisme.html#a6428a0fc8326f50acbdf24f6a134e60b',1,'Organisme']]]
];
