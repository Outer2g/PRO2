var searchData=
[
  ['ranking',['Ranking',['../class_ranking.html',1,'']]]
];
